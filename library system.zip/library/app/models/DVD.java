package models;

import java.util.ArrayList;

public class DVD extends LibraryItem {

    //Instance variables.
    private ArrayList<String> availableLanguages;
    private ArrayList<String> availableSubtitles;
    private ArrayList<String> actors;

    //DVD class constructor.
    public DVD(String ISBN, String title, String sector, DateTime publicationDate,ArrayList<String> actors, ArrayList<String> availableLanguages, ArrayList<String> availableSubtitles){

        super(ISBN, title, sector, publicationDate);
        this.availableLanguages = availableLanguages;
        this.availableSubtitles = availableSubtitles;

        this.actors = actors;

    }

    //Getters and Setters.
    public ArrayList<String> getAvailableLanguages() {
        return availableLanguages;
    }

    public ArrayList<String> getAvailableSubtitles() {
        return availableSubtitles;
    }

    public ArrayList<String> getActors() {
        return actors;
    }


    public void setAvailableLanguages(ArrayList<String> availableLanguages) {
        this.availableLanguages = availableLanguages;
    }

    public void setAvailableSubtitles(ArrayList<String> availableSubtitles) {
        this.availableSubtitles = availableSubtitles;
    }

    public void setActors(ArrayList<String> actors) {
        this.actors = actors;
    }



}