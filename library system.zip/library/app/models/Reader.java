package models;

public class Reader {

    //Instance variables.
    private String readerId;
    private String name;
    private String phoneNumber;
    private String email;

    //Constructor for Reader class.
    public Reader(String readerId, String name, String email, String phoneNumber){

        this.readerId = readerId;
        this.name = name;
        this.phoneNumber = phoneNumber;
        this.email = email;

    }

    public Reader(String readerId, String name){

        this.readerId = readerId;
        this.name = name;


    }

    //Getters and Setters.
    public String getReaderId() {
        return readerId;
    }

    public String getEmail() {
        return email;
    }

    public String getName() {
        return name;
    }

    public String getPhoneNum() {
        return phoneNumber;
    }

    public void setReaderId(String readerId) {
        this.readerId = readerId;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPhoneNum(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

}