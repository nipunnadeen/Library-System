package models;


import java.util.ArrayList;

public class Book extends LibraryItem {

    //Instance variables.


    private String totalPages;
    private String publisher;
    private ArrayList<String> authors;



    //Book class constructor.
    public Book(String ISBN, String title, String sector, DateTime publicationDate,ArrayList<String> authors,String publisher, String totalPages){

        super(ISBN, title, sector,publicationDate);

        this.totalPages = totalPages;
        this.publisher = publisher;
        this.authors = authors;

    }

    //Getters and Setters.

    public ArrayList<String> getAuthors() {
        return authors;
    }

    public void setAuthors(ArrayList<String> authors) {
        this.authors = authors;
    }

    public String getPublisher() {
        return publisher;
    }

    public void setPublisher(String publisher) {
        this.publisher = publisher;
    }

    public String getTotalPages() {
        return totalPages;
    }
    public void setTotalPages(String totalPages) {
        this.totalPages = totalPages;
    }

}
