package models;



import java.sql.SQLException;

public interface LibraryManager {


    public abstract void addBookInterface(Book book) throws SQLException;
    public abstract void addDVDInterface(DVD dvd) throws SQLException;
    public abstract void borrowItems(LibraryItem libraryitem, Reader reader) throws SQLException;
    public abstract void deleteItem(LibraryItem libraryitems)throws SQLException;
    public abstract void returnItem(LibraryItem returnlibraryitem)throws SQLException;
    public abstract void itemReport();
    public abstract void addReaderInterface(Reader reader) throws SQLException;
}
