package models;

public class LibraryItem {

    //Instance variables.
    private String ISBN;
    private String title;
    private String sector;
    private DateTime publicationDate;
    private DateTime borrowedDate;
//    private DateTime borrowedTime;


    //LibraryItem class constructor.
    public LibraryItem(String ISBN, String title, String sector, DateTime publicationDate){

        this.ISBN = ISBN;
        this.title = title;
        this.sector = sector;
        this.publicationDate = publicationDate;

    }


    public LibraryItem(String ISBN,DateTime borrowedDate){

        this.ISBN = ISBN;
        this.borrowedDate = borrowedDate;
//        this.borrowedTime = borrowedTime;
    }

    public LibraryItem(String ISBN){

        this.ISBN = ISBN;

    }




    //Getters and Setters.
    public String getISBN() {
        return ISBN;
    }

    public String getTitle() {
        return title;
    }

    public String getSector() {
        return sector;
    }

    public DateTime getPublicationDate() {
        return publicationDate;
    }

    public DateTime getBorrowedDate() {
        return borrowedDate;
    }

//    public DateTime getBorrowedTime() {
//        return borrowedTime;
//    }

//    public void setBorrowedTime(DateTime borrowedTime) {
//        this.borrowedTime = borrowedTime;
//    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setSector(String sector) {
        this.sector = sector;
    }

    public void setPublicationDate(DateTime publicationDate) {
        this.publicationDate = publicationDate;
    }

    public void setBorrowedDate(DateTime borrowedDate) {
        this.borrowedDate = borrowedDate;
    }

}