package controllers;
import com.fasterxml.jackson.databind.JsonNode;
import connection.DatabaseConnection;
import models.*;

import play.mvc.*;
import play.libs.Json;

import java.sql.*;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;


class AppSummary {

    private String content;

    AppSummary(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

}

public class WestminsterLibraryManager extends Controller implements LibraryManager {





    public Result addbook() throws SQLException {

        String addbookData = request().body().asText();

        DatabaseConnection connectionClass = new DatabaseConnection(); //create a object to get the database connection to methode
        Connection connection=connectionClass.getConnection();
        //pass input data to json object
        JsonNode json = Json.parse(addbookData);

        //asign the values to string one by one
         String isbn = json.get("itemisbn").textValue();
         String title = json.get("booktitle").textValue();
         String sector = json.get("booksector").textValue();
         String bpdate = json.get("bpdate").textValue();
         String bookauthors = json.get("bookauthors").textValue();
         String bookpublisher = json.get("bookpublisher").textValue();
         String bookpages = json.get("bookpages").textValue();

         String[] dateBreak = bpdate.split("-"); //break the date using java spliter
         int year = Integer.parseInt(dateBreak[0]);  //year
         int month = Integer.parseInt(dateBreak[1]); //month
         int day = Integer.parseInt(dateBreak[2]); //day

        String[] authorsBreak = bookauthors.split(",");  //break thorough the comma





        DateTime datetime = new DateTime(month,day,year);  //use the date time class to call the constructer of the class
        ArrayList<String> numauthors  = new ArrayList<String>(Arrays.asList(authorsBreak));  //get the input authors to an array list

        Book book = new Book(isbn,title,sector,datetime,numauthors,bookpublisher,bookpages);   //use the book class to call the constructer of the class





        //queries
        String check1 = "SELECT `isbn` FROM `book` WHERE `isbn`=? ";
        String check2 = "SELECT `isbn` FROM `dvd` WHERE `isbn`=? ";


         //queries
        String query = "SELECT * FROM `book`";


        ArrayList tableList = new ArrayList();
        //arralist for get the nuber of rows
        Statement st = connection.createStatement();  //statement
        ResultSet rs = st.executeQuery(query);  //exicute query



        while (rs.next()) {

            ArrayList list = new ArrayList();
            //get the isbn colomn values sum and pase it to anothe list

            list.add(rs.getString(1));

            tableList.add(list);
        }

        int numBook = tableList.size();


        if(bookpages.matches("\\d+")) {
            //check whethe the input is a number
            if(isbn.matches("\\d+")) {

              if (ISBNChecking(check1) == 1 ) {   //if there is a same input value in the book table. this will exscute
                JsonNode jsonNode = Json.toJson(new AppSummary("ISBN is already use by a book"));
                return ok(jsonNode).as("application/json");
           } else {
              if (ISBNChecking(check2) == 1) {  //if there is a same input value in the dvd table. this will exscute
                JsonNode jsonNode = Json.toJson(new AppSummary("ISBN is already use by a dvd"));
                return ok(jsonNode).as("application/json");
            } else {
                  //if the row sum is greater than current list sum this will exicute
                        if (numBook <= 99) {

                            addBookInterface(book);   // send the final data to interface methode

                            while (rs.next()) {

                                ArrayList list1 = new ArrayList();


                                list1.add(rs.getString(1));

                                tableList.add(list1);
                            }

                            int newSumBook = tableList.size();

                            int freeSpaces = 99 - newSumBook;

                            JsonNode jsonNode = Json.toJson(new AppSummary("The book was added successfully and there are " + freeSpaces + " Spaces free"));
                            return ok(jsonNode).as("application/json");

                        } else {

                            //else this will excicute
                            JsonNode jsonNode = Json.toJson(new AppSummary("there is no space to add Book"));
                            return ok(jsonNode).as("application/json");


                        }

                   }
                }
            }else{
            JsonNode jsonNode = Json.toJson(new AppSummary("ISBN must be a number"));
            return ok(jsonNode).as("application/json");
           }

        }else{
        JsonNode jsonNode = Json.toJson(new AppSummary("Number of book pages must be a number"));
        return ok(jsonNode).as("application/json");
        }

    }








    public Result adddvd() throws SQLException {
        String adddvdData = request().body().asText();

        DatabaseConnection connectClass = new DatabaseConnection();  //create a object to get the database connection to methode
        Connection connection = connectClass.getConnection();
       //pass input data to json object
        JsonNode json = Json.parse(adddvdData);
        //asign the values to string one by one
        String isbn = json.get("itemisbn").textValue();
        String title = json.get("dvdtitle").textValue();
        String sector = json.get("dvdsector").textValue();
        String dpdate = json.get("dpdate").textValue();
        String actors = json.get("dvdactors").textValue();
        String language = json.get("dvdlang").textValue();
        String sub = json.get("dvdsub").textValue();




        String[] dateBreak = dpdate.split("-");

        int year = Integer.parseInt(dateBreak[0]);
        int month = Integer.parseInt(dateBreak[1]);  //break the date using java spliter
        int day = Integer.parseInt(dateBreak[2]);

        String[] breakcomma1 = actors.split(",");
        String[] breakcomma2 = language.split(",");
        String[] breakcomma3 = sub.split(",");

        //break the actors,language and subtitles using java spliter

        DateTime datetime = new DateTime(month,day,year);

        ArrayList<String> numactors  = new ArrayList<String>(Arrays.asList(breakcomma1)); //pass the inputs to arraylist


        ArrayList<String> numlang  = new ArrayList<String>(Arrays.asList(breakcomma2));


        ArrayList<String> numsub  = new ArrayList<String>(Arrays.asList(breakcomma3));


        DVD dvd = new DVD(isbn,title,sector,datetime,numactors,numlang,numsub);






        String check1 = "SELECT `isbn` FROM `book` WHERE `isbn`=? ";
        String check2 = "SELECT `isbn` FROM `dvd` WHERE `isbn`=? ";




        String query = "SELECT * FROM `dvd`";


        ArrayList tableList = new ArrayList();

        Statement st = connection.createStatement();
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {

            ArrayList list = new ArrayList();

            list.add(rs.getString(1));

            tableList.add(list);


        }

       int numDVD = tableList.size();


        if (ISBNChecking(check1) == 1) {
            JsonNode jsonNode = Json.toJson(new AppSummary("ISBN is already use by a book"));
            return ok(jsonNode).as("application/json");
        } else {
            if (ISBNChecking(check2) == 1) {
                JsonNode jsonNode = Json.toJson(new AppSummary("ISBN is already use by a dvd"));
                return ok(jsonNode).as("application/json");
            } else {
                if(isbn.matches("\\d+")) {

                if (numDVD<=49) {


                 addDVDInterface(dvd);

                 while (rs.next()) {

                     ArrayList list = new ArrayList();


                     list.add(rs.getString(1));

                     tableList.add(list);
                 }

                 int newSumDVD = tableList.size();

                 int freeSpaces = 49 - newSumDVD;

                 JsonNode jsonNode = Json.toJson(new AppSummary("The DVD was added successfully and there are "+freeSpaces+" Spaces free"));
                 return ok(jsonNode).as("application/json");


               } else {


                   JsonNode jsonNode = Json.toJson(new AppSummary("there is no space to add DVD"));
                 return ok(jsonNode).as("application/json");
                }

                }else{
                    JsonNode jsonNode = Json.toJson(new AppSummary("ISBN must be a number"));
                    return ok(jsonNode).as("application/json");
                }

            }

        }

    }

    public Result delete() throws SQLException {


        String deleteData = request().body().asText();

        DatabaseConnection connectClass = new DatabaseConnection(); //get the database connection
        Connection connection = connectClass.getConnection();

        JsonNode json = Json.parse(deleteData);
        System.out.print(json.get("itemisbn").textValue());

        String isbn = json.get("itemisbn").textValue();

        LibraryItem libraryitems = new LibraryItem(isbn);

        String check1 = "SELECT `isbn` FROM `book` WHERE `isbn`=? ";
        String check2 = "SELECT `isbn` FROM `dvd` WHERE `isbn`=? ";

        String borrowCheck = "SELECT `isbn` FROM `borrow_data` WHERE `isbn`=? ";

      if(ISBNChecking(borrowCheck) == 1){

          JsonNode jsonNode = Json.toJson(new AppSummary("Sorry you can't delete it right now because it was already borrowed. Please until it returns "));
          return ok(jsonNode).as("application/json");

      }else{

         if(isbn.matches("\\d+")) {

             if (ISBNChecking(check1) == 1) {

        deleteItem(libraryitems);


        String query = "SELECT * FROM `book`";


        ArrayList tableList = new ArrayList();

        Statement st = connection.createStatement();
        ResultSet rs = st.executeQuery(query);

        while (rs.next()) {

            ArrayList list = new ArrayList();

            list.add(rs.getString(1));

            tableList.add(list);
        }

        int numBook = tableList.size();

        int bookSum = 100 - numBook;

        JsonNode jsonNode = Json.toJson(new AppSummary("Delete Item Type is Book and there are " + bookSum + " Spaces"));
        return ok(jsonNode).as("application/json");
    } else {
        if (ISBNChecking(check2) == 1) {


            deleteItem(libraryitems);


            String query = "SELECT * FROM `dvd`";

            ArrayList pid_list = new ArrayList();

            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(query);


            while (rs.next()) {

                ArrayList list = new ArrayList();

                list.add(rs.getString(1));

                pid_list.add(list);
            }

            int numDVD = pid_list.size();

            int DvdSum = 50 - numDVD;

            JsonNode jsonNode = Json.toJson(new AppSummary("Delete Item Type is DVD and there are " + DvdSum + " Spaces"));
            return ok(jsonNode).as("application/json");
        } else {

            JsonNode jsonNode = Json.toJson(new AppSummary("isbn doesnt exsists"));
            return ok(jsonNode).as("application/json");

           }
        }
      }else{
            JsonNode jsonNode = Json.toJson(new AppSummary("ISBN must be a number"));
            return ok(jsonNode).as("application/json");
        }
      }

    }

    public Result borrow() throws SQLException, ParseException{
        String borrowData = request().body().asText();



        JsonNode json = Json.parse(borrowData);


        String borrowisbn = json.get("itemisbn").textValue();
        String borrowdate = json.get("borrowdate").textValue();
        String borrowtime = json.get("borrowtime").textValue();
        String readerid = json.get("readerid").textValue();
        String readername = json.get("readername").textValue();


        String[] borrowDateBreak = borrowdate.split("-");


        int year = Integer.parseInt(borrowDateBreak[0]);
        int month = Integer.parseInt(borrowDateBreak[1]);
        int day = Integer.parseInt(borrowDateBreak[2]);


        String[] borrowTimeBreak = borrowtime.split(":");


        int hour = Integer.parseInt(borrowTimeBreak[0]);
        int minute = Integer.parseInt(borrowTimeBreak[1]);

        DateTime date = new DateTime(month,day,year,hour,minute);

        LibraryItem libraryitem = new LibraryItem(borrowisbn,date);  // library item constructer
        Reader reader = new Reader(readerid,readername);   // reader clz constructer

        String check1 = "SELECT `isbn` FROM `book` WHERE `isbn`=? ";
        String check2 = "SELECT `isbn` FROM `dvd` WHERE `isbn`=? ";
        String borrowCheck = "SELECT `isbn` FROM `borrow_data` WHERE `isbn`=? ";
        String readerCheck = "SELECT `id` FROM `reader` WHERE `id`=? ";


        String borowed_Date = null;
        String bDate = borrowDateReturn(borowed_Date);


        if (ISBNChecking(check1) == 0 && ISBNChecking(check2) == 0) {

            JsonNode jsonNode = Json.toJson(new AppSummary("ISBN doesn't exists"));
            return ok(jsonNode).as("application/json");

        } else {

            if(borrowisbn.matches("\\d+")){

              if (ISBNChecking(borrowCheck) == 1) {

                if (ISBNChecking(check1) == 1) {




                    String dateValue = bDate;
                    String format = "yyyy-MM-dd";  //formatetter

                    SimpleDateFormat dateformat = new SimpleDateFormat(format);  //date formatter

                    Calendar calendarObj = Calendar.getInstance();  // get the claender library
                    calendarObj.setTime(dateformat.parse(dateValue));  //pass the date value to date format

                    calendarObj.add(Calendar.DATE, 7); //this one for book and it will add 7 days to date
                    dateValue = dateformat.format(calendarObj.getTime());  // get the current date

                    JsonNode jsonNode = Json.toJson(new AppSummary("This book is already borrowed. It will return on " + dateValue));
                    return ok(jsonNode).as("application/json");

                } else {



                    String dateValue = bDate;
                    String format = "yyyy-MM-dd";   //formatetter

                    SimpleDateFormat dateformat = new SimpleDateFormat(format);  //date formatter

                    Calendar calendarObj = Calendar.getInstance();  // get the claender library
                    calendarObj.setTime(dateformat.parse(dateValue));   //pass the date value to date format

                    calendarObj.add(Calendar.DATE, 3);  //this one for dvd and it will add 3 days to date
                    dateValue = dateformat.format(calendarObj.getTime());   // get the current date

                    JsonNode jsonNode = Json.toJson(new AppSummary("This DVD is already borrowed. It will return on " + dateValue));
                    return ok(jsonNode).as("application/json");


                }

            } else {

                if (readeridChecking(readerCheck) == 0) {
                    JsonNode jsonNode = Json.toJson(new AppSummary("Reader ID doesn't exists"));
                    return ok(jsonNode).as("application/json");
                } else {
                    if (ISBNChecking(check1) == 1) {


                        borrowItems(libraryitem, reader);


                        JsonNode jsonNode = Json.toJson(new AppSummary("Reader borrowed the book successfully"));
                        return ok(jsonNode).as("application/json");
                    } else {

                        borrowItems(libraryitem, reader);


                        JsonNode jsonNode = Json.toJson(new AppSummary("Reader borrowed the DVD successfully"));
                        return ok(jsonNode).as("application/json");
                    }
                }
            }

            }else{
                JsonNode jsonNode = Json.toJson(new AppSummary("ISBN must be a number"));
                return ok(jsonNode).as("application/json");
            }
        }
    }




    public Result returnall() throws SQLException, ParseException {

        String addreturnData = request().body().asText();



        JsonNode json = Json.parse(addreturnData);

        String returnisbn = json.get("itemisbn").textValue();
        String rdate = json.get("rdate").textValue();
        String rtime = json.get("rtime").textValue();


        String[] borrowDateBreak = rdate.split("-");


        int year = Integer.parseInt(borrowDateBreak[0]);
        int month = Integer.parseInt(borrowDateBreak[1]);
        int day = Integer.parseInt(borrowDateBreak[2]);

        DateTime date = new DateTime(month, day, year);


        String[] borrowTimeBreak = rtime.split(":");


        int hour = Integer.parseInt(borrowTimeBreak[0]);
        int minute = Integer.parseInt(borrowTimeBreak[1]);

        DateTime time = new DateTime(month, day, year, hour, minute);

        LibraryItem returnlibraryitem = new LibraryItem(returnisbn, date);


        String check1 = "SELECT `isbn` FROM `book` WHERE `isbn`=? ";
        String check2 = "SELECT `isbn` FROM `dvd` WHERE `isbn`=? ";

        String borrowCheck = "SELECT `isbn` FROM `borrow_data` WHERE `isbn`=? ";

        String readerCheck = "SELECT `id` FROM `reader` WHERE `id`=? ";

        String borowed_Date = null;
        String bDate = borrowDateReturn(borowed_Date);


        String borowed_time = null;
        String bTime = borrowTimeReturn(borowed_time);



        int sumOfExceededHours;
        double sumOfFirstThree = 0;
        double sumOfAfterFirstThree = 0;


if(returnisbn.matches("\\d+")) {

    if (ISBNChecking(check1) == 0 & ISBNChecking(check2) == 0) {

        JsonNode jsonNode = Json.toJson(new AppSummary("ISBN doesn't exists"));
        return ok(jsonNode).as("application/json");

    } else {

        if (ISBNChecking(borrowCheck) == 0) {
            JsonNode jsonNode = Json.toJson(new AppSummary("This item is not borrowed"));
            return ok(jsonNode).as("application/json");
        } else {

            if (readeridChecking(readerCheck) == 0) {
                JsonNode jsonNode = Json.toJson(new AppSummary("Reader ID doesn't exists"));
                return ok(jsonNode).as("application/json");
            } else {

                String format = "yyyy-MM-dd hh:mm ";     //date formatter

                SimpleDateFormat df = new SimpleDateFormat(format);  //date formatter

                Date rdatetime = df.parse(date.getDate() + " " + time.getTime() + " ");  //pass the return date and time
                Date bdatetime = df.parse(bDate + " " + bTime + " ");  //pass the borrow date and time
                System.out.println(rdatetime);
                System.out.println(bdatetime + "\n");

                DecimalFormat convertDecimalFormat = new DecimalFormat("###,###"); // convert to decimal format

                System.out.println(rdatetime.getTime()); //print them on console to check only
                System.out.println(bdatetime.getTime());

                long difference = rdatetime.getTime() - bdatetime.getTime();

                int rbDifferenceDays = (int) (difference / (24 * 60 * 60 * 1000)); //convert to days
                System.out.println("days: " + rbDifferenceDays);

                int rbDifferenceHours = (int) (difference / (60 * 60 * 1000));  // convert to hours
                System.out.println(" hours: " + convertDecimalFormat.format(rbDifferenceHours));


                if (ISBNChecking(check1) == 1) {


                    if ((rbDifferenceDays >= 8)) {   //if th different days is greater than or similar to 8 this will excute

                        sumOfExceededHours = rbDifferenceHours - 24 * 7;   //get the exceed hours by removing borrow available hours

                        if (sumOfExceededHours <= 24 * 3) {  //check the excedded hours is minimum or similar than 3 days hours
                            sumOfFirstThree = (sumOfExceededHours) * 0.2;   //get the hours payment
                            System.out.println("7 days up for book");

                            returnItem(returnlibraryitem);  // pass the data to interface methode


                            JsonNode jsonNode = Json.toJson(new AppSummary("The book was returned successfully. The Book is available now.The Reader should pay £" + sumOfFirstThree));
                            return ok(jsonNode).as("application/json");


                        }
                        if (sumOfExceededHours > 24 * 3) {  //check the excedded hours is maximum  than 3 days hours

                            sumOfAfterFirstThree = (sumOfExceededHours - 24 * 3) * 0.5;   //get the after 3 days hours payment
                            int finalSum = (int) (sumOfAfterFirstThree + 24 * 3 * 0.2);   // sum of the 3 days hours payment and other exceed hours

                            System.out.println("7 days and 3 days up for book");
                            returnItem(returnlibraryitem);


                            JsonNode jsonNode = Json.toJson(new AppSummary("The book was returned successfully. The book is available now. The Reader should pay £" + finalSum));
                            return ok(jsonNode).as("application/json");
                        }


                    } else {   // pass the data to interface methode
                        returnItem(returnlibraryitem);
                        System.out.println("not days up");
                          //if the exceed hours is 0 this will excute
                        JsonNode jsonNode = Json.toJson(new AppSummary("The book was returned successfully. The book is available now."));
                        return ok(jsonNode).as("application/json");
                    }


                } else {

                    if ((rbDifferenceDays >= 4)) {    //if th different days is greater than or similar to 4 this will excute
                        sumOfExceededHours = rbDifferenceHours - 24 * 3;   //get the exceed hours by removing borrow available hours
                        if (sumOfExceededHours <= 24 * 3) {   //check the excedded hours is minimum or similar than 3 days hours

                            sumOfFirstThree = (sumOfExceededHours) * 0.2;   //get the hours payment
                            System.out.println("3 days up for dvd");


                            returnItem(returnlibraryitem);  // pass the data to interface methode

                            JsonNode jsonNode = Json.toJson(new AppSummary("The DVD was returned successfully. The DVD is available now.The reader should pay £" + sumOfFirstThree));
                            return ok(jsonNode).as("application/json");

                        }
                        if (sumOfExceededHours > 24 * 3) {  //check the excedded hours is maximum  than 3 days hours

                            sumOfAfterFirstThree = (sumOfExceededHours - 24 * 3) * 0.5;  //get the after 3 days hours payment
                            int finalSum = (int) (sumOfAfterFirstThree + 24 * 3 * 0.2);  // sum of the 3 days hours payment and other exceed hours

                            System.out.println("7 days and 3 days up for dvd");

                            returnItem(returnlibraryitem);  // pass the data to interface methode

                            JsonNode jsonNode = Json.toJson(new AppSummary("The DVD was returned successfully. The DVD is available now.The reader should pay £" + finalSum));
                            return ok(jsonNode).as("application/json");
                        }


                    } else {    // pass the data to interface methode
                        returnItem(returnlibraryitem);
                        //if the exceed hours is 0 this will excute
                        JsonNode jsonNode = Json.toJson(new AppSummary("The DVD was returned successfully. The item is available now"));
                        return ok(jsonNode).as("application/json");
                    }

                }
              }
            }

          }

        }else{
          JsonNode jsonNode = Json.toJson(new AppSummary("ISBN must be a number"));
          return ok(jsonNode).as("application/json");
       }
        return ok().as("application/json");
    }






    public Result allItemList() throws SQLException {


        String addreturnData = request().body().asText();

        JsonNode json = Json.parse(addreturnData);

        String returnisbn = json.get("itemisbn").textValue();



        DatabaseConnection connectClass = new DatabaseConnection(); //get the database connection
        Connection connection = connectClass.getConnection();






        String query = "SELECT * FROM `dvd` ";

        Statement st = connection.createStatement();
        ResultSet rs = st.executeQuery(query);



        while (rs.next()) {




            ArrayList list = new ArrayList();




            list.add(rs.getString(1));
            list.add(rs.getString(2));
            list.add(rs.getString(3));
            list.add(rs.getString(4));
            list.add(rs.getString(5));
            list.add(rs.getString(6));
            list.add(rs.getString(7));



            for(int i = 1;i<list.size();i++){
                System.out.print(rs.getString(i));
                JsonNode jsonNode = Json.toJson(new AppSummary(rs.getString(i)));
                return ok(jsonNode).as("application/json");
            }


        }


        JsonNode jsonNode = Json.toJson(new AppSummary(""));
        return ok(jsonNode).as("application/json");

    }




    public Result addReader() throws SQLException{

        String readerData = request().body().asText();



        JsonNode json = Json.parse(readerData);


        String id = json.get("readerid").textValue();
        String name = json.get("readername").textValue();
        String email = json.get("readeremail").textValue();
        String tele = json.get("readertele").textValue();

        Reader reader = new Reader(id,name,email,tele);


        String check = "SELECT `id` FROM `reader` WHERE `id`=? ";


        if (readeridChecking(check) == 1) {
            JsonNode jsonNode = Json.toJson(new AppSummary("ID is already used by a another reader"));
            return ok(jsonNode).as("application/json");
        } else {

            addReaderInterface(reader);  // pass the data to interface methode

            JsonNode jsonNode = Json.toJson(new AppSummary("Reader added successfully"));
            return ok(jsonNode).as("application/json");
            }

        }












    public int ISBNChecking(String var) throws SQLException {

        DatabaseConnection connectionClass = new DatabaseConnection();
        Connection connection=connectionClass.getConnection();

        String adddvdData = request().body().asText();

        JsonNode json = Json.parse(adddvdData);

        PreparedStatement pre = connection.prepareStatement(var);

        pre.setString(1, json.get("itemisbn").textValue());


        ResultSet res = pre.executeQuery();


        int tableCount = 0;

        while (res.next()) {
            tableCount = tableCount + 1;


        }


        return tableCount;

    }



    public int readeridChecking(String var) throws SQLException {

        DatabaseConnection connectionClass = new DatabaseConnection();
        Connection connection=connectionClass.getConnection();

        String borrowitm = request().body().asText();

        JsonNode json = Json.parse(borrowitm);

        PreparedStatement pre = connection.prepareStatement(var);


        pre.setString(1, json.get("readerid").textValue());

        ResultSet res = pre.executeQuery();



        int tableCount = 0;

        while (res.next()) {
            tableCount = tableCount + 1;

        }

        return tableCount;

    }

    public String borrowDateReturn(String borowed_Date) throws SQLException {

        DatabaseConnection connectionClass = new DatabaseConnection();
        Connection connection=connectionClass.getConnection();

        String borrowitm = request().body().asText();

        JsonNode json = Json.parse(borrowitm);



     String isbn = json.get("itemisbn").textValue();

        Statement st1 = connection.createStatement();
        ResultSet rest1 = st1.executeQuery("SELECT borrow_date FROM borrow_data where isbn= '" +isbn+ "'");




        while (rest1.next()){
            borowed_Date=rest1.getString("borrow_date");
        }

        System.out.print(borowed_Date);

        return borowed_Date;

    }




    public String borrowTimeReturn(String borowed_time) throws SQLException {

        DatabaseConnection connectionClass = new DatabaseConnection();
        Connection connection=connectionClass.getConnection();

        String borrowitm = request().body().asText();

        JsonNode json = Json.parse(borrowitm);



        String isbn = json.get("itemisbn").textValue();

        Statement st1 = connection.createStatement();
        ResultSet rest1 = st1.executeQuery("SELECT borrow_time FROM borrow_data where isbn= '" +isbn+ "'");




        while (rest1.next()){
            borowed_time=rest1.getString("borrow_time");
        }



        return borowed_time;

    }













    @Override
    public void addBookInterface(Book book) throws SQLException {  //interface methode

        DatabaseConnection connectClass = new DatabaseConnection(); //get the database connection
        Connection connection = connectClass.getConnection();


        String sql = "INSERT INTO book VALUES('" + book.getISBN() + "','" + book.getTitle() + "','" + book.getSector() + "','" + book.getPublicationDate().getDate()+ "','" + book.getAuthors() + "','" + book.getPublisher() + "','" + book.getTotalPages() + "')";



        Statement stat = connection.createStatement();
        stat.executeUpdate(sql);


    }

    @Override
    public void addDVDInterface(DVD dvd) throws SQLException {  //interface methode

        DatabaseConnection connectClass = new DatabaseConnection(); //get the database connection
        Connection connection = connectClass.getConnection();


        String sql = "INSERT INTO dvd VALUES('" + dvd.getISBN() + "','" + dvd.getTitle() + "','" + dvd.getSector() + "','" + dvd.getPublicationDate().getDate() + "','" + dvd.getActors() + "','" + dvd.getAvailableLanguages() + "','" + dvd.getAvailableSubtitles() + "')";
        //then insert all values to database table

        Statement stat = connection.createStatement();
        stat.executeUpdate(sql);

    }

    @Override
    public void borrowItems(LibraryItem libraryitem, Reader reader) throws SQLException{ //interface methode

        DatabaseConnection connectClass = new DatabaseConnection();//get the database connection
        Connection connection = connectClass.getConnection();


        String sql = "INSERT INTO borrow_data VALUES('" + libraryitem.getISBN() + "','" + libraryitem.getBorrowedDate().getDate() + "','" + libraryitem.getBorrowedDate().getTime() + "','" + reader.getReaderId() + "','" + reader.getName() + "')";


        Statement stat = connection.createStatement();
        stat.executeUpdate(sql);

    }



    @Override
    public void deleteItem(LibraryItem libraryitems) throws SQLException{   //interface methode

        DatabaseConnection connectClass = new DatabaseConnection();//get the database connection
        Connection connection = connectClass.getConnection();


        String deleteQry1 = "DELETE FROM book WHERE isbn = " + libraryitems.getISBN();

        Statement stat = connection.createStatement();
        stat.executeUpdate(deleteQry1);

        String deleteQry2 = "DELETE FROM dvd WHERE isbn = " + libraryitems.getISBN();


        Statement state = connection.createStatement();
        state.executeUpdate(deleteQry2);

    }

    @Override
    public void returnItem(LibraryItem returnlibraryitem) throws SQLException{  //interface methode

        DatabaseConnection connectClass = new DatabaseConnection();//get the database connection
        Connection connection = connectClass.getConnection();


        String deleteQry = "DELETE FROM borrow_data WHERE isbn = " + returnlibraryitem.getISBN();


        Statement stat = connection.createStatement();
        stat.executeUpdate(deleteQry);

    }


    @Override
    public void itemReport() {

    }


    @Override
    public void addReaderInterface(Reader reader) throws SQLException {  //interface methode

        DatabaseConnection connectClass = new DatabaseConnection(); //get the database connection
        Connection connection = connectClass.getConnection();


        String sql = "INSERT INTO reader VALUES('" + reader.getReaderId() + "','" + reader.getName() + "','" + reader.getEmail() + "','" + reader.getPhoneNum() +  "')";
        //then insert all values to database table

        Statement stat = connection.createStatement();
        stat.executeUpdate(sql);


    }



    public Result appSummary() {

        JsonNode jsonNode = Json.toJson(new AppSummary(""));
        return ok(jsonNode).as("application/json");
    }
}
