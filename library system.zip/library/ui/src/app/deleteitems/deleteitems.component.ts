import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {HttpClient} from "@angular/common/http";
import {AppService} from "../app.service";

@Component({
  selector: 'app-deleteitems',
  templateUrl: './deleteitems.component.html',
  styleUrls: ['./deleteitems.component.css']
})
export class DeleteitemsComponent implements OnInit {

  deleteItemForm: FormGroup;

  postRequestResponse: string;
  title: string;

  constructor(private http: HttpClient, private appservice: AppService) {


    this.appservice.deleteRes().subscribe((data: any) => {
      this.title = data.content;
    });


  }

  ngOnInit() {

    this.deleteItemForm = new FormGroup({
      itemisbn: new FormControl('', Validators.required),
    })

  }

  onSubmit(){

    let deleteIsbn = JSON.stringify(this.deleteItemForm.value);
    this.appservice.delete(deleteIsbn).subscribe((data: any) => {;

    this.postRequestResponse = data.content;

    this.deleteItemForm.reset();

    });

  }

}
