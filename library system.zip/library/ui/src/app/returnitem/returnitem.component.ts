import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {HttpClient} from "@angular/common/http";
import {AppService} from "../app.service";

@Component({
  selector: 'app-returnitem',
  templateUrl: './returnitem.component.html',
  styleUrls: ['./returnitem.component.css']
})
export class ReturnitemComponent implements OnInit {

  ReturnitemsForm: FormGroup;
  postRequestResponse: string;
  title: string;

  constructor(private http: HttpClient, private appservice: AppService) {

    this.appservice.returnRes().subscribe((data: any) => {
      this.title = data.content;
    });

  }


  ngOnInit() {

    this.ReturnitemsForm = new FormGroup({

      itemisbn: new FormControl('', Validators.required),
      readerid: new FormControl('', Validators.required),
      rdate: new FormControl('', Validators.required),
      rtime: new FormControl('', Validators.required),


    })

  }

  onSubmit(){

    let returnitems = JSON.stringify(this.ReturnitemsForm.value);
    this.appservice.returnitm(returnitems).subscribe((data: any) => {;

      this.postRequestResponse = data.content;;

    this.ReturnitemsForm.reset();

    });

  }

}
