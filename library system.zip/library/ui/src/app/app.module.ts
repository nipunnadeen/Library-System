import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HTTP_INTERCEPTORS, HttpClientModule, HttpClientXsrfModule } from '@angular/common/http';

import { AppComponent } from './app.component';

import { AppService } from './app.service';
import { AppHttpInterceptorService } from './http-interceptor.service';
import { AddbookComponent } from './addbook/addbook.component';

import { HomeComponent } from './home/home.component';

import {ReactiveFormsModule, FormGroup, FormsModule} from "@angular/forms";
import { AdddvdComponent } from './adddvd/adddvd.component';
import { DeleteitemsComponent } from './deleteitems/deleteitems.component';
import { BorrowitemComponent } from './borrowitem/borrowitem.component';
import { ReturnitemComponent } from './returnitem/returnitem.component';
import { AddreaderComponent } from './addreader/addreader.component';
import { ItemlistComponent } from './itemlist/itemlist.component';

const routes: Routes = [
  {
    path:'',
    component: HomeComponent
  },

  {
    path:'addreader',
    component: AddreaderComponent
  },
  {
    path:'addbook',
    component: AddbookComponent
  },
  {
    path:'adddvd',
    component: AdddvdComponent
  },

  {
    path:'deleteitems',
    component: DeleteitemsComponent
  },

  {
    path:'borrowitem',
    component: BorrowitemComponent
  },

  {
    path:'itemlist',
    component: ItemlistComponent
  },

  {
    path:'returnitem',
    component: ReturnitemComponent
  }

];

@NgModule({
  declarations: [
    AppComponent,
    AddbookComponent,
    HomeComponent,
    AdddvdComponent,
    DeleteitemsComponent,
    BorrowitemComponent,
    ReturnitemComponent,
    AddreaderComponent,
    ItemlistComponent,

  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientXsrfModule.withOptions({
      cookieName: 'Csrf-Token',
      headerName: 'Csrf-Token',
    }),
    RouterModule.forRoot(routes)
  ],
  providers: [
    AppService,
    {
      multi: true,
      provide: HTTP_INTERCEPTORS,
      useClass: AppHttpInterceptorService
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}
