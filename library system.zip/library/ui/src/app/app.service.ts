import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/index';
import {HttpClient} from "@angular/common/http";
import { map } from 'rxjs/operators';
/**
 * Class representing application service.
 *
 * @class AppService.
 */
@Injectable()
export class AppService {

  private addbookItem = '/api/addbookitems';
  private adddvdItem = '/api/adddvditems';
  private deleteItem = '/api/deleteitems';
  private borrowItem = '/api/borrowitems';
  private returnItem = '/api/returnitems';
  private addReader = '/api/addreader';
  private itemList = '/api/itemlist';

  constructor(private http: HttpClient) {}


  public bookRes() {
    return this.http.get(this.addbookItem).pipe(
      map(response => response)
    );
  }

  public dvdRes() {
    return this.http.get(this.adddvdItem).pipe(
      map(response => response)
    );
  }

  public readerRes() {
    return this.http.get(this.addReader).pipe(
      map(response => response)
    );
  }

  public deleteRes() {
    return this.http.get(this.deleteItem).pipe(
      map(response => response)
    );
  }

  public borrowRes() {
    return this.http.get(this.borrowItem).pipe(
      map(response => response)
    );
  }

  public returnRes() {
    return this.http.get(this.borrowItem).pipe(
      map(response => response)
    );
  }


  public itemRes() {
    return this.http.get(this.itemList).pipe(
      map(response => response)
    );
  }





  public addbook(data: any): Observable<any> {

    return this.http.post(this.addbookItem, data);

  }

  public adddvd(data: any): Observable<any> {

    return this.http.post(this.adddvdItem, data);


  }

  public addreader(data: any): Observable<any> {

    return this.http.post(this.addReader, data);



  }

  public delete(data: any): Observable<any> {
    return this.http.post(this.deleteItem, data);
  }

  public borrowitm(data: any): Observable<any> {

    return this.http.post(this.borrowItem, data);

  }

  public returnitm(data: any): Observable<any> {

    return this.http.post(this.returnItem, data);

  }

  public List(data: any): Observable<any> {

    return this.http.post(this.itemList, data);

  }

}

