import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {HttpClient} from "@angular/common/http";
import {AppService} from "../app.service";

@Component({
  selector: 'app-adddvd',
  templateUrl: './adddvd.component.html',
  styleUrls: ['./adddvd.component.css']
})
export class AdddvdComponent implements OnInit {

  AdddvdForm: FormGroup;

  postRequestResponse: string;
  title: string;

  constructor(private http: HttpClient, private appservice: AppService) {

    this.appservice.dvdRes().subscribe((data: any) => {
      this.title = data.content;
    });

  }

  ngOnInit() {

    this.AdddvdForm = new FormGroup({

      itemisbn: new FormControl('', Validators.required),
      dvdtitle: new FormControl('', Validators.required),
      dvdsector: new FormControl('', Validators.required),
      dpdate: new FormControl('', Validators.required),
      dvdactors: new FormControl('', Validators.required),
      dvdlang: new FormControl('', Validators.required),
      dvdsub: new FormControl('', Validators.required),


    })
  }

  onSubmit(){

    let addall = JSON.stringify(this.AdddvdForm.value);
    this.appservice.adddvd(addall).subscribe((data: any) => {

    this.postRequestResponse = data.content;

    this.AdddvdForm.reset();

    });
  }

}
