import { Component, OnInit } from '@angular/core';
import {HttpClient} from "@angular/common/http";
import {AppService} from "../app.service";
import {FormControl, FormGroup, Validators} from "@angular/forms";

@Component({
  selector: 'app-itemlist',
  templateUrl: './itemlist.component.html',
  styleUrls: ['./itemlist.component.css']
})
export class ItemlistComponent implements OnInit {

  listForm: FormGroup;
  postRequestResponse: string;
  title: string;


  constructor(private http: HttpClient, private appservice: AppService) {



    this.appservice.itemRes().subscribe((data: any) => {
      this.title = data.content;
      this.postRequestResponse = data.content;
    });



  }

  ngOnInit() {
    // this.getscholardetails(this.route.snapshot.params['id']);
    this.listForm = new FormGroup({

      itemisbn: new FormControl('', Validators.required),


    })
  }

  onSubmit(){

    let addall = JSON.stringify(this.listForm.value);
    this.appservice.List(addall).subscribe((data: any) => {
      this.postRequestResponse = data.content;





    });
  }




}
