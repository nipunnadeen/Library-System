import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {HttpClient} from "@angular/common/http";
import {AppService} from "../app.service";

@Component({
  selector: 'app-addreader',
  templateUrl: './addreader.component.html',
  styleUrls: ['./addreader.component.css']
})
export class AddreaderComponent implements OnInit {

  AddreaderForm: FormGroup;

  postRequestResponse: string;
  title: string;

  constructor(private http: HttpClient, private appservice: AppService) {

    this.appservice.readerRes().subscribe((data: any) => {
      this.title = data.content;
    });


  }

  ngOnInit() {

    this.AddreaderForm = new FormGroup({

      readerid: new FormControl('', Validators.required),
      readername: new FormControl('', Validators.required),
      readeremail: new FormControl('', Validators.required),
      readertele: new FormControl('', Validators.required),


    })

  }

  onSubmit(){

    let reader = JSON.stringify(this.AddreaderForm.value);
    this.appservice.addreader(reader).subscribe((data: any) => {;

      this.postRequestResponse = data.content;

      this.AddreaderForm.reset();

    });
  }

}
