import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {HttpClient} from "@angular/common/http";
import {AppService} from "../app.service";


@Component({
  selector: 'app-addbook',
  templateUrl: './addbook.component.html',
  styleUrls: ['./addbook.component.css']
})
export class AddbookComponent implements OnInit {

  AddbookForm: FormGroup;

  postRequestResponse: string;
  title: string;

  constructor(private http: HttpClient, private appservice: AppService) {

    this.appservice.bookRes().subscribe((data: any) => {
      this.title = data.content;

      this.postRequestResponse = data.content;
    });


  }

  ngOnInit() {

    this.AddbookForm = new FormGroup({

      itemisbn: new FormControl('', Validators.required),
      booktitle: new FormControl('', Validators.required),
      booksector: new FormControl('', Validators.required),
      bpdate: new FormControl('', Validators.required),
      bookauthors: new FormControl('', Validators.required),
      bookpublisher: new FormControl('', Validators.required),
      bookpages: new FormControl('', Validators.required),



    })

  }

  onSubmit(){

    let addall = JSON.stringify(this.AddbookForm.value);
    this.appservice.addbook(addall).subscribe((data: any) => {
      this.postRequestResponse = data.content;

      this.AddbookForm.reset();



    });
  }

}
