import { Component, OnInit } from '@angular/core';
import {FormControl, FormGroup, Validators} from "@angular/forms";
import {HttpClient} from "@angular/common/http";
import {AppService} from "../app.service";

@Component({
  selector: 'app-borrowitem',
  templateUrl: './borrowitem.component.html',
  styleUrls: ['./borrowitem.component.css']
})
export class BorrowitemComponent implements OnInit {

  borrowitemForm: FormGroup;

  postRequestResponse: string;
  title: string;

  constructor(private http: HttpClient, private appservice: AppService) {

    this.appservice.borrowRes().subscribe((data: any) => {
      this.title = data.content;
    });


  }

  ngOnInit() {

    this.borrowitemForm = new FormGroup({

      itemisbn: new FormControl('', Validators.required),
      borrowdate: new FormControl('', Validators.required),
      borrowtime: new FormControl('', Validators.required),
      readerid: new FormControl('', Validators.required),
      readername: new FormControl('', Validators.required),




    })


  }

  onSubmit(){

    let borrowIsbn = JSON.stringify(this.borrowitemForm.value);
    this.appservice.borrowitm(borrowIsbn).subscribe((data: any) => {

      this.postRequestResponse = data.content;

      this.borrowitemForm.reset();



    });

  }
}
